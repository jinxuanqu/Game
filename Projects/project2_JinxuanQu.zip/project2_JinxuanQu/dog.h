#include <iostream>
#include <cstring>

class Dog {
public:
	 Dog(const char* d):name(new char[strlen(d)+1])
	 {
		addDog();
		strcpy(name, d);
	 }
	Dog(const Dog& s):name(new char[strlen(s.name)+1])
	{
		strcpy(name, s.name);
	}

	const char* getName() const {
		return name;
	}
	void setName(const char* d){
		delete[] name;
		name = new char[strlen(d)+1];
		strcpy(name, d);
	}
	static void addDog();
	Dog& operator=(Dog& rhs);

	~Dog() {delete []name;}
private:
	char* name;
	static int dogNum;
	Dog();
};
std::ostream& operator<<(std::ostream& out, const Dog& rhs );
Dog& operator++(Dog& rhs);
Dog& operator--(Dog& rhs);	