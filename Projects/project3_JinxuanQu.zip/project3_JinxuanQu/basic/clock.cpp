#include <cmath>
#include <iostream>
#include <string>
#include <sstream>
#include "clock.h"
#include "gamedata.h"
#include "ioManager.h"

Clock& Clock::getInstance() {
  if ( SDL_WasInit(SDL_INIT_VIDEO) == 0) {
    throw std::string("Must init SDL before Clock");
  }
  static Clock clock; 
  return clock;
}

Clock::Clock() :
  ticks(0),
  started(false), 
  paused(false), 
  sloMo(false), 
  sumOfTicks(0),
  frames(0)
  {
  start();
}

Clock::Clock(const Clock& c) :
  ticks(c.ticks), 
  started(c.started), 
  paused(c.paused), 
  sloMo(c.sloMo), 
  sumOfTicks(c.sumOfTicks),
  frames(c.frames)
  {
  start();
}

void Clock::draw() const { 
  IOManager::getInstance().
    printMessageValueAt("ticks: ", ticks, 10, 30);
}

void Clock::update() { 
  //ticks = 5;
  //sumOfTicks += ticks;
  if(!paused){
    ++frames;
    int currentTicks = SDL_GetTicks();
    ticks = currentTicks - sumOfTicks;
    sumOfTicks +=ticks;
  }  
}
 


unsigned int Clock::getTicksSinceLastFrame() const {
  if (paused) return 0;
  else if ( sloMo ) return 1;

  return ticks;
}

void Clock::toggleSloMo() {
  sloMo = !sloMo;
}

int Clock::getFps() const { 
  int seconds = sumOfTicks/1000.0;
  //std::cout<<"**seconds:"<<seconds<<std::endl;
  //std::cout<<"**frames:"<<frames<<std::endl;
  if(seconds>0){
  std::cout<<"fps: "<<frames/seconds<<std::endl;
  return frames/seconds;}
  return 0;
}

void Clock::start() { 
  started = true; 
  paused = false; 
  
}

void Clock::pause() { 
  if(started && !paused )
    paused = true;
}

void Clock::unpause() { 
  if(started && paused )
    paused = false;
}

