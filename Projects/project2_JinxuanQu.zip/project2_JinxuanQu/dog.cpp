#include <iostream>
#include <cstring>
#include "dog.h"

void Dog::addDog() {
	dogNum++;
	std::cout<<"we have:"<<dogNum<<"dogs"<<std::endl;
	}
Dog& Dog::operator=(Dog& rhs){
	if(this == &rhs) return *this;
	delete[] name;
	name = new char[strlen(rhs.name)+1];
	strcpy(name, rhs.name);
	return *this;
	}

    int Dog::dogNum = 0;
	std::ostream& operator<<(std::ostream& out, const Dog& rhs ){
		return out<<rhs.getName();
	}
	Dog& operator++(Dog& rhs){
		std::cout<<"operator++: "<<rhs.getName()<<" has borned a dog."<<std::endl;
		Dog::addDog();
		return rhs;
	}
	Dog& operator--(Dog& rhs){
		std::cout<<"operator--: "<<rhs.getName()<<" 's child has died."<<std::endl;
		Dog::addDog();
		return rhs;
	}
