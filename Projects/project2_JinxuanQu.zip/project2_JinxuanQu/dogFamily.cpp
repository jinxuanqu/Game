#include "dogFamily.h"
#include <iostream>

DogFamily& DogFamily::getInstance(){
	static DogFamily instance;
	return instance;
}

void DogFamily::run(){
		Dog Dad("John");
		std::cout<< Dad<<" has borned"<<std::endl;
		Dog Mom("Kate");
		std::cout<< Mom<<" has borned"<<std::endl;
		++Mom;
	}
	