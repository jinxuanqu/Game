#include "dog.h"

class DogFamily{
public:
	static DogFamily& getInstance();
	void run();
private:
	DogFamily(const DogFamily&);
	DogFamily& operator=(DogFamily&);
	DogFamily(){	
	}
};
