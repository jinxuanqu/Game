#include "dogFamily.h"
int main()
{
    DogFamily& DogFamily = DogFamily::getInstance();
    DogFamily.run();
    return 0;
}